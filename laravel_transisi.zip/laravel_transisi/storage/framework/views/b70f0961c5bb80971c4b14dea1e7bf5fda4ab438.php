<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Update Data 
                </div>

                <div class="card-body">
                
                    <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="update" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($p->id); ?>"> <br/>

                        <div class="form-group">
                                <label for="pekerjaan">Nama</label>
                                <input class="form-control" type="text" name="nama" value="<?php echo e($p->nama); ?>">
                        </div>
                        <div class="form-group">
                                <label for="pekerjaan">Email</label>
                                <input class="form-control" type="text" name="email" value="<?php echo e($p->email); ?>">
                        </div>
                        <div class="form-group">
                                <label for="pekerjaan">Logo</label>
                                <input class="form-control" type="text" name="logo" value="<?php echo e($p->logo); ?>">
                        </div>
                        <div class="form-group">
                                <label for="pekerjaan">Website</label>
                                <input class="form-control" type="text" name="website" value="<?php echo e($p->website); ?>">
                        </div>
                        <!-- Nama <input type="text" required="required" name="nama" value="<?php echo e($p->nama); ?>"> <br/>
                        Email <input type="text" required="required" name="email" value="<?php echo e($p->email); ?>"> <br/>
                        Website <textarea required="required" name="website"><?php echo e($p->website); ?></textarea> <br/> -->
                        <input type="submit" class="btn btn-success " value="Update">
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_transisi/resources/views/company/edit.blade.php ENDPATH**/ ?>