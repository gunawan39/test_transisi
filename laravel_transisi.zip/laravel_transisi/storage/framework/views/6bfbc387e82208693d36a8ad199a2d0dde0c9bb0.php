<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>

    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h2> Data Companies</h2> 

                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                  <a href="tambah"  class="btn btn-success "> + Tambah</a>
                   <a href="cetak_pdf" class="btn btn-primary" target="_blank">Cetak pdf</a>
                    <br>
                    <br>

                    Total Data : <?php echo e($companies->total()); ?> <br/>
                    <table class='table table-bordered'>
                        <tr>
                            <th align="center" >No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Website</th>
                            <th>Opsi</th>
                        </tr>
                        <?php $i=1 ?>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align=center><?php echo e($i++); ?></td>
                            <td><?php echo e($p->nama); ?></td>
                            <td><?php echo e($p->email); ?></td>
                            <td><?php echo e($p->website); ?></td>
                            <td>
                            <a href="edit/<?php echo e($p->id); ?>"  class="btn btn-success">  Edit</a>
                                <button type="button" onclick="deleteItem(<?php echo e($p->id); ?>)" id="Reco" class="btn btn-danger">Delete</button>         
                       
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <br/>
                    Page : <?php echo e($companies->currentPage()); ?> <br/>
                    <?php echo e($companies->links()); ?>

                </div>


            </div>
        </div>
    </div>
</div>

<script>
function deleteItem(id) {
    $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({ 
            type: "get", 
            url: 'hapus/'+id,               
            dataType: "JSON",
            success: function(data) {
           
                if(data.message == 200){
                    // toastr.success("Berhasil Hapus data");
                   
                    toastr.success(
                        'Berhasil Hapus data ',
                        {
                            timeOut: 1000,
                        },
                        location.reload(),
                    );

                }
                    
            }
        });          
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_transisi/resources/views/company/index.blade.php ENDPATH**/ ?>